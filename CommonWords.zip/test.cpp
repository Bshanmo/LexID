#include <iostream>
#include <string>
#include <iostream>
#include <fstream>
#include <cctype>
#include <cstdlib>
#include <sstream>
using namespace std;

void fillArray(const char * filename, string array[], int SIZE);
void checkChar(string array[], string end[], char letter, int place, int size);

int main()
{
	int a = 0;
	int amount[15] = {0,2,37,223,637,688,686,635,504,354,274,161,71,41,21};
	char exe;
	int pos;
	cout << "Hello World!\n";
	cout << "How many letters are in your word?\n";
	cin >> a;
	/*
	char *st = itoa(a);
	string add = string(st);
	//string add = (char)a;
	*/
	stringstream ss;
	ss << a;
	string add = ss.str();
	string testing = "CommonWords";
	testing += add;
	testing += ".txt";
	const char * final = testing.c_str();
	string found[10];
	const int size = amount[a];
	string list[size];
	fillArray(final,list, size);
	/*
	//This sets the array for the certain word
	switch(a)
	{

		case 2:
			//string * list = new string[amount[a]];
			fillArray("CommonWords2.txt", list, amount[a]);
			//cout << "two";
			break;
		case 3:
			//string * list = new string[amount[a]];
			fillArray("CommonWords3.txt", list, amount[a]);
			//cout << "Three";
			break;
		case 4:
			cout << "Four";
			break;
		case 5:
			cout << "Five";
			break;
		case 6:
			cout << "Six";
			break;
		case 7:
			cout << "Seven";
			break;
		case 8:
			cout << "Eight";
			break;
		case 9:
			cout << "Nine";
			break;
		case 10:
			cout << "Ten";
			break;
		case 11:
			cout << "Eleven";
			break;
		case 12:
			fillArray("CommonWords12.txt", list, amount[a]);
			//cout << "Twelve";
			break;
			
	}
	*/
	//Need to test certain characters for a word
	cout << "Which character would you like to search for?";
	cin >> exe;
	cout << "Where would you like to find it?";
	cin >> pos;
	checkChar(list,found,exe,pos, amount[a]);
	
	
	
	
}

void fillArray(const char * filename, string array[], int SIZE)
{
	ifstream input(filename);
	string word;
	for (int i = 0; i < SIZE; i++)
	{
		input >> word;
		//cout << word;
		array[i] = word;
		//cout << endl;
	}
	/*
    int first, last, delta;
    ifstream input("myInput.txt");
    input >> first >> last >> delta;
    cout << first << " " << last << " " << delta << endl;
    input.close();
    */
}

void checkChar(string array[], string end[], char letter, int place, int size)
{
	cout << "Here are the first 10 words matching your criteria:\n";
	int j = 0;
	for (int i = 0; i < 10; i++)
	{
		bool skip = false;
		while(skip == false)
		{
			
			if (array[j][place] == letter)
			{
				skip = true;
			}
			j++;
			if (j >= size - 1)
			{
				skip = true;
			}
		}
		if (j == size - 1)
		{
			//cout << array[j];
			i = 10;
		}
		else
		{
			end[i] = array[j-1];
			cout << i << end[i];
		}
	}
	cout << "Array filled";
}
